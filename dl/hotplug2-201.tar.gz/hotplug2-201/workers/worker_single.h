#ifndef WORKER_SINGLE_H
#define WORKER_SINGLE_H 1

#include "../action.h"
#include "../settings.h"

#include "worker.h"

#endif
