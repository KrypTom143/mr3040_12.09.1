#ifndef XMEMUTILS_H
#define XMEMUTILS_H 1

inline void *xmalloc(size_t);
inline void *xrealloc(void *, size_t);

#endif /* XMEMUTILS */
